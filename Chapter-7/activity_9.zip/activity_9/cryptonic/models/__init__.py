"""
Cryptocurrency prediction models.
"""
